<?php 

// Konfigurasi Sistem Informasi Pelayanan Surat Pengantar Kelurahan Kalibaros
return array(
    'logo' => 'images/logo_kotapekalongan.png',
    'kode_kelurahan' => '3375021012',
    'kode_kecamatan' => '045.2',
    'kode_kota' => '06.35',
    'nama_lurah'=> 'Supriyadi S.E.',
    'nip_lurah'=> '88107561233250002',
 );

?>